import { MongoClient, ObjectId } from "mongodb";

async function dbConnection() {
  try {
    const client = new MongoClient("mongodb+srv://maryammamdouh2002_db:Maryam%402002@cluster0.duofh22.mongodb.net/?appName=Cluster0/SocialMediaDB");
    await client.connect();

    console.log("DB connected");

    return client;
  } catch (error) {
    console.log("failed to connect to DB");
  }
}


export const handler = async (event) => {
  try {
    const client = await dbConnection();

    const db = client.db("SocialMediaDB");
    const userCollection = db.collection("users");

    for (const record of event.Records) {
      const Key = decodeURIComponent(record.s3.object.Key);
      console.log("file uploaded: " + Key);

      const userId = Key.split("/")[2];

      const result = await userCollection.updateOne(
        {
          _id: ObjectId.createFromHexString(userId),
        },
        {
          $set: { profilePic: Key },
        },
      );

      console.log(result);
    }
  } catch (error) {
    console.log("err in lambda function: " + error);
  }
};

handler({
  Records: [
    {
      s3: {
        object: {
          Key: "social-media-app/user/6a2bd521567e78c277119fbd/profilePic/10ddfcfc-c1f1-4e32-a8c8-54202f54a8c6_one.png",
        },
      },
    },
  ],
});